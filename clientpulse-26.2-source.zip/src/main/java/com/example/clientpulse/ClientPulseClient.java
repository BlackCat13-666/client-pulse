package com.example.clientpulse;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import org.lwjgl.glfw.GLFW;

public final class ClientPulseClient implements ClientModInitializer {
    public static final String MOD_ID = "clientpulse";

    private static final KeyMapping TOGGLE_HUD = KeyMappingHelper.registerKeyMapping(
            new KeyMapping(
                    "key.clientpulse.toggle_hud",
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_H,
                    KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"))
            )
    );

    private static boolean hudEnabled = true;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                ClientPulseClient::renderHud
        );
    }

    private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();

        while (TOGGLE_HUD.consumeClick()) {
            hudEnabled = !hudEnabled;
        }

        if (!hudEnabled || mc.player == null || mc.level == null) {
            return;
        }

        LocalPlayer player = mc.player;
        Level level = mc.level;

        int x = 8;
        int y = 8;
        int width = 154;
        int height = 72;

        // Subtle animated accent, based only on local time.
        double t = System.currentTimeMillis() / 1000.0;
        int accent = 0xFF55CCFF;
        int accent2 = 0xFFAA77FF;
        float phase = (float) ((Math.sin(t * 1.5) + 1.0) * 0.5);
        int ar = lerp((accent >> 16) & 255, (accent2 >> 16) & 255, phase);
        int ag = lerp((accent >> 8) & 255, (accent2 >> 8) & 255, phase);
        int ab = lerp(accent & 255, accent2 & 255, phase);
        int animatedAccent = 0xFF000000 | (ar << 16) | (ag << 8) | ab;

        graphics.fill(x, y, x + width, y + height, 0xB0101018);
        graphics.fill(x, y, x + width, y + 2, animatedAccent);

        graphics.drawString(mc.font, "ClientPulse", x + 7, y + 7, 0xFFFFFFFF, true);
        graphics.drawString(mc.font, "FPS  " + mc.getFps(), x + 7, y + 21, 0xFFE0E0E8, false);

        int px = player.blockPosition().getX();
        int py = player.blockPosition().getY();
        int pz = player.blockPosition().getZ();
        graphics.drawString(mc.font, "XYZ  " + px + " " + py + " " + pz, x + 7, y + 34, 0xFFE0E0E8, false);

        String facing = player.getDirection().getName().toUpperCase(java.util.Locale.ROOT);
        graphics.drawString(mc.font, "Facing  " + facing, x + 7, y + 47, 0xFFE0E0E8, false);

        String dimension = level.dimension().identifier().toString();
        graphics.drawString(mc.font, dimension, x + 7, y + 60, animatedAccent, false);
    }

    private static int lerp(int a, int b, float amount) {
        return Math.round(a + (b - a) * amount);
    }
}
