# ClientPulse — Fabric 26.2

ClientPulse is a small, strictly client-side visual utility mod.

## Features

- Toggleable HUD with **H**
- FPS counter
- XYZ coordinates
- Facing direction
- Current dimension
- Animated accent bar
- No server component
- No custom packets
- No mixins
- Uses Fabric's 26.2 HUD API rather than raw OpenGL

## Compatibility

- Minecraft 26.2
- Fabric Loader 0.19.5+
- Fabric API 0.155.2+26.2
- Java 25+

## Build

Run:

    ./gradlew build

The finished JAR is written to:

    build/libs/clientpulse-1.0.0.jar

Put that JAR in your Minecraft `mods` directory alongside Fabric API.

## Notes

"100% client side" means the mod only registers a client entrypoint and performs rendering/input locally. It does not add server-side content or require a server mod.
